import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import '../../css/header.css'

export class Header extends Component {
    render() {
        return (
            <div className="heder_section">
                <nav className="navbar navbar-expand-lg navbar-light container">
                    <Link to={'/'} className="navbar-brand">
                        <img src="images/logo-header.png" className="logo_img" alt="logo"/>
                    </Link>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link">Start Investing</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link">Raise Capital</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link">About</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link btn btn-primary btn-sm login_btn" >Login </Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link">Language <i className="fa fa-angle-down"></i></Link>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div className="navbar navbar-expand-lg navbar-light footer_navbar">
                    <div className="container footer_nav-sub">
                        <ul className="collapse navbar-collapse navbar-nav mr-auto footer_nav_sub">
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link">Live Offering</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link">Upcoming Offering</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/'} className="nav-link">Success Funded</Link>
                            </li>
                        </ul>
                    </div>
                </div>    
            </div>
        )
    }
}

export default Header
